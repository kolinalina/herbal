<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KecModel extends Model
{
    //
    protected $table = 'kec';
    protected $fillable = ['kec'];
}
