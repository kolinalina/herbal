@extends('admin_page')
@section('content')

			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>

			<center style="margin-top:250px; font-style:'bold'; font-size:40px;"> SELAMAT DATANG DI DASHBOARD ADMIN
								
            </div><!--/row-->
            </div><!--/.fluid-container-->
	
            
@endsection