<?php $__env->startSection('content'); ?>

  <div class="slider-area">
            <div class="zigzag-bottom"></div>
            <div id="slide-list" class="carousel carousel-fade slide" data-ride="carousel">

                <div class="slide-bulletz">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <ol class="carousel-indicators slide-indicators">
                                    <li data-target="#slide-list" data-slide-to="0" class="active"></li>
                                    <li data-target="#slide-list" data-slide-to="1"></li>
                                    <li data-target="#slide-list" data-slide-to="2"></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <div class="single-slide">
                            <div class="slide-bg slide-one"></div>
                            <div class="slide-text-wrapper">
                                <div class="slide-text">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6 col-md-offset-6">
                                                <div class="slide-content">
                                                    <h2>Complete Product</h2>
                                                    <p>Menyediakan berbagai jenis tanaman herbal, mulai dari bibit dan tanamannya.
                                                    </p>
                                                    <p>Diambil dari tanaman yang berkualitas.</p>
                                                    <!-- <a href="" class="readmore">Learn more</a> -->
                                                    <p>
                                                        <div class="product-wid-rating" style="text-align: right">
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="single-slide">
                            <div class="slide-bg slide-two"></div>
                            <div class="slide-text-wrapper">
                                <div class="slide-text">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6 col-md-offset-6">
                                                <div class="slide-content">
                                                    <h2>Trusted</h2>
                                                    <p>Mengedepankan kepuasaan pelanggan dengan cara menjaga bibit tanaman yang
                                                        unggul dan berkualitas.</p>
                                                    <p>Proses pengiriman yang aman dan cepat merupakan cara untuk menjaga kualitas
                                                        produk sampai ditangan customer.
                                                    </p>

                                                    <!-- <a href="" class="readmore">Learn more</a> -->
                                                    <p>
                                                        <div class="product-wid-rating" style="text-align: right">
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="single-slide">
                            <div class="slide-bg slide-three"></div>
                            <div class="slide-text-wrapper">
                                <div class="slide-text">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6 col-md-offset-6">
                                                <div class="slide-content">
                                                    <h2>Modern</h2>
                                                    <p>Pemanfaatan teknologi untuk mengoptimalkan penjualan yang maksimal</p>
                                                    <p>Efisien merupakan salah satu misi dari perusahaan</p>
                                                    <!-- <a href="" class="readmore">Learn more</a> -->
                                                    <p>
                                                        <div class="product-wid-rating" style="text-align: right">
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End slider area -->

        <!-- <div class="promo-area">
            <div class="zigzag-bottom"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="single-promo">

                            <a href="#popup" class="popup-link">

                                <i class="fa fa-refresh"></i>

                                <p>7 Days return</p>
                            </a>
                        </div>

                        <div class="popup-wrapper" id="popup">
                           
                            <div class="popup-container">
                                <div id="closed"></div>
                                <h2>7 Days return</h2>
                                <p>Pembelian akan bisa dikembalikan selama pembelian tidak lebih dari 7 hari
                                    atau selama kurun waktu masih seminggu
                                    <br/><br/>
                                    <strong>Happy shop plant's guys :)</strong>
                                </p>

                                <a class="popup-close" href="#closed">X</a>
                          
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="single-promo">
                            <div id="closed"></div>
                            <a href="#popup" class="popup-link">
                                <i class="fa fa-truck"></i>
                                <p>Free shipping</p>
                            </a>
                        </div>

                        <div class="popup-wrapper" id="popup">
                            <div class="popup-container">
                                <div id="closed"></div>
                                <h2>Free Shipping</h2>
                                <p>
                                    Gratis antar jika melakukan pemesanan plant lebih dari yang ditentukan. Dan
                                    terdapat Diskon antar bagi yang mempunyai voucher dari HerbShop

                                    <br/><br/>
                                    <strong>Happy shop plant's guys :)</strong>
                                </p>

                                <a class="popup-close" href="#closed">X</a>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="single-promo">
                            <a href="#popup" class="popup-link">

                              
                                <i class="fa fa-lock"></i>
                                <p>Secure payments</p>
                            </a>
                        </div>
                        <div class="popup-wrapper" id="popup">
                            <div class="popup-container">
                                <div id="closed"></div>
                                <h2>Secure Payment</h2>
                                <p>
                                        Proses transaksi pembayaran yang aman dan mudah, dan dapat dilakukan dengan Via
                                        Cash ataupun Transfer
                                    <br/><br/>
                                    <strong>Happy shop plant's guys :)</strong>
                                </p>

                                <a class="popup-close" href="#closed">X</a>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="single-promo">
                            <a href="#popup" class="popup-link">

                                
                                <i class="fa fa-gift"></i>
                                <p>Promotions</p>
                            </a>
                        </div>
                        <div class="popup-wrapper" id="popup">
                            <div class="popup-container">
                                <div id="closed"></div>
                                <h2>Promotions</h2>
                                <p>
                                    HerbShop menyediakan banyak promosi yang menarik untuk pelanggan
                                    <br/><br/>
                                    <strong>Happy shop plant's guys :)</strong>
                                </p>

                                <a class="popup-close" href="#closed">X</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        End promo area -->

        <br>
        <div class="maincontent-area">
            <div class="zigzag-bottom"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="latest-product">
                            <h2 class="section-title">New Product</h2>
                            <div class="product-carousel">
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="img/product-1.jpg" alt="">
                                        <div class="product-hover">
                                            <a href="#" class="add-to-cart-link">
                                                <i class="fa fa-shopping-cart"></i>
                                                Add to cart</a>
                                            <a href="single-product.html" class="view-details-link">
                                                <i class="fa fa-link"></i>
                                                See details</a>
                                        </div>
                                    </div>

                                    <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>

                                    <div class="product-carousel-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.000</del>
                                    </div>
                                </div>
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="img/product-2.jpg" alt="">
                                        <div class="product-hover">
                                            <a href="#" class="add-to-cart-link">
                                                <i class="fa fa-shopping-cart"></i>
                                                Add to cart</a>
                                            <a href="single-product.html" class="view-details-link">
                                                <i class="fa fa-link"></i>
                                                See details</a>
                                        </div>
                                    </div>

                                    <h2>
                                        <a href="single-product.html">Kemangi</a>
                                    </h2>
                                    <div class="product-carousel-price">
                                        <ins>Rp.15.000</ins>
                                        <del>Rp.30.000</del>
                                    </div>
                                </div>
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="img/product-3.jpg" alt="">
                                        <div class="product-hover">
                                            <a href="#" class="add-to-cart-link">
                                                <i class="fa fa-shopping-cart"></i>
                                                Add to cart</a>
                                            <a href="single-product.html" class="view-details-link">
                                                <i class="fa fa-link"></i>
                                                See details</a>
                                        </div>
                                    </div>

                                    <h2>
                                        <a href="single-product.html">Seledri</a>
                                    </h2>

                                    <div class="product-carousel-price">
                                        <ins>Rp.13.000</ins>
                                        <del>Rp.20.000</del>
                                    </div>
                                </div>
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="img/product-4.jpg" alt="">
                                        <div class="product-hover">
                                            <a href="#" class="add-to-cart-link">
                                                <i class="fa fa-shopping-cart"></i>
                                                Add to cart</a>
                                            <a href="single-product.html" class="view-details-link">
                                                <i class="fa fa-link"></i>
                                                See details</a>
                                        </div>
                                    </div>

                                    <h2>
                                            <a href="single-product.html">Kemangi</a>
                                        </h2>
                                        <div class="product-carousel-price">
                                            <ins>Rp.15.000</ins>
                                            <del>Rp.30.000</del>
                                        </div>
                                </div>
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="img/product-5.jpg" alt="">
                                        <div class="product-hover">
                                            <a href="#" class="add-to-cart-link">
                                                <i class="fa fa-shopping-cart"></i>
                                                Add to cart</a>
                                            <a href="single-product.html" class="view-details-link">
                                                <i class="fa fa-link"></i>
                                                See details</a>
                                        </div>
                                    </div>

                                    <h2>
                                            <a href="single-product.html">Kemangi</a>
                                        </h2>
                                        <div class="product-carousel-price">
                                            <ins>Rp.15.000</ins>
                                            <del>Rp.30.000</del>
                                        </div>
                                </div>
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="img/product-6.jpg" alt="">
                                        <div class="product-hover">
                                            <a href="#" class="add-to-cart-link">
                                                <i class="fa fa-shopping-cart"></i>
                                                Add to cart</a>
                                            <a href="single-product.html" class="view-details-link">
                                                <i class="fa fa-link"></i>
                                                See details</a>
                                        </div>
                                    </div>

                                    <h2>
                                            <a href="single-product.html">Kemangi</a>
                                        </h2>
                                        <div class="product-carousel-price">
                                            <ins>Rp.15.000</ins>
                                            <del>Rp.30.000</del>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End main content area -->

        

        <div class="product-widget-area">
            <div class="zigzag-bottom"></div>
            <div class="container">
                <div class="row">
                        <h2 class="section-title">Top Product</h2><br>
                    <div class="col-md-4">
                        <div class="single-product-widget">
                          
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-1.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                    <a href="single-product.html">Daun Mint</a>
                                </h2>
                                <div class="product-wid-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="product-wid-price">
                                    <ins>Rp.20.000</ins>
                                    <del>Rp.30.0000</del>
                                </div>
                            </div>
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-2.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                    <a href="single-product.html">Kemangi</a>
                                </h2>
                                <div class="product-wid-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="product-wid-price">
                                    <ins>Rp.15.000</ins>
                                    <del>Rp.30.000</del>
                                </div>
                            </div>
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-3.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                    <a href="single-product.html">Seledri</a>
                                </h2>
                                <div class="product-wid-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="product-wid-price">
                                    <ins>Rp.13.000</ins>
                                    <del>Rp.20.000</del>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-product-widget">
                            
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-4.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>
                                    <div class="product-wid-rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-wid-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.0000</del>
                                    </div>
                            </div>
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-1.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>
                                    <div class="product-wid-rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-wid-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.0000</del>
                                    </div>
                            </div>
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-2.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>
                                    <div class="product-wid-rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-wid-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.0000</del>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-product-widget">
                           
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-3.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>
                                    <div class="product-wid-rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-wid-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.0000</del>
                                    </div>
                            </div>
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-4.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>
                                    <div class="product-wid-rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-wid-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.0000</del>
                                    </div>
                            </div>
                            <div class="single-wid-product">
                                <a href="single-product.html"><img src="img/product-thumb-1.jpg" alt="" class="product-thumb"></a>
                                <h2>
                                        <a href="single-product.html">Daun Mint</a>
                                    </h2>
                                    <div class="product-wid-rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-wid-price">
                                        <ins>Rp.20.000</ins>
                                        <del>Rp.30.0000</del>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End product widget area -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\herbshop\resources\views/page/home_content.blade.php ENDPATH**/ ?>