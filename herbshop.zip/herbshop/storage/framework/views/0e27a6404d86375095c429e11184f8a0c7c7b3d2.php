<?php $__env->startSection('content'); ?>

			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>

			<center style="margin-top:250px; font-style:'bold'; font-size:40px;"> SELAMAT DATANG DI DASHBOARD ADMIN
								
            </div><!--/row-->
            </div><!--/.fluid-container-->
	
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\herbshop\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>