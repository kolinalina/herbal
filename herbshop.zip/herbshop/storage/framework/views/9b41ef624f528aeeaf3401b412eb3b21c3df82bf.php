<?php $__env->startSection('content'); ?>

 <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>Shop</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Search Products</h2>
                        <form action="">
                            <input type="text" placeholder="Search products...">
                            <input type="submit" value="Search">
                        </form>
                    </div>

                     <div class="single-sidebar">
                        <h2 class="sidebar-title">Category</h2>
                        <ul>
                             <?php
                                $all_category=DB::table('category')
                                    ->where('category_status',1)
                                    ->get();

                                foreach($all_category as $v_categoryy){
                            ?>

                            <li><a href="<?php echo e(URL::to('/product-category/'.$v_categoryy->category_id)); ?>"><?php echo e($v_categoryy->category_add); ?></a></li>
                            <?php } ?>
                        </ul>
                           
                    </div>
                  
                </div>
                
                <div class="col-md-8">
                    <div class="product-content-right">
                            <div class="product-breadcroumb">
                                    <a href="<?php echo e(url('/product')); ?>">All Product</a>
                                        
                                        
                            </div>
                        
                      
                        </div>
                        
                        
          <div class="container">
            <div class="row">
            <?php $__currentLoopData = $all_product_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_categoryyy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-sm-6">
                    <div class="single-shop-product">
                        <div class="product-upper">
                            <img src="<?php echo e(URL::to($v_categoryyy->product_image)); ?>" alt="">
                        </div>
                        <h2><a href="<?php echo e(URL::to('/view-product/'.$v_categoryyy->product_id)); ?>"><?php echo e($v_categoryyy->product_name); ?></a></h2>
                        <div class="product-carousel-price">
                            <ins>Rp.<?php echo e($v_categoryyy->product_price2); ?></ins> <del>Rp.<?php echo e($v_categoryyy->product_price); ?></del>
                        </div>  
                        
                        <div class="product-option-shop">
                            <a class="add_to_cart_button" data-quantity="1" data-product_sku="" data-product_id="70" rel="nofollow" href="/canvas/shop/?add-to-cart=70">Add to cart</a>
                        </div>                       
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
               
            </div>
            </div>
           
            
            <div class="row">
                <div class="col-md-12">
                    <div class="product-pagination text-center">
                        <nav>
                          <ul class="pagination">
                            <li>
                              <a href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                              </a>
                            </li>
                            <li><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li>
                              <a href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                      </ul>
                    </nav>                        
                </div>
            </div>
        </div>
       
           

                        
                        
                        
                        <div class="related-products-wrapper">
                            <h2 class="related-products-title">Related Products</h2>
                           
                            <div class="related-products-carousel">
                            <?php $__currentLoopData = $all_product_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-product">
                                    <div class="product-f-image">
                                        <img src="<?php echo e(URL::to($v_product->product_image)); ?>"  alt="">
                                        <div class="product-hover">
                                            <a href="<?php echo e(URL::to('/view-product/'.$v_product->product_id)); ?>" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                            <a href="<?php echo e(URL::to('/view-product/'.$v_product->product_id)); ?>" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                        </div>
                                    </div>

                                    

                                    <h2><a href="<?php echo e(URL::to('/view-product/'.$v_product->product_id)); ?>"><?php echo e($v_product->product_name); ?></a></h2>

                                    <div class="product-carousel-price">
                                        <ins>Rp.<?php echo e($v_product->product_price2); ?></ins> <del>Rp.<?php echo e($v_product->product_price2); ?></del>
                                    </div> 
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                                                 
                            </div>
                           
                        </div>
                       
                    </div> 
                           
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\herbshop\resources\views/page/product_category.blade.php ENDPATH**/ ?>